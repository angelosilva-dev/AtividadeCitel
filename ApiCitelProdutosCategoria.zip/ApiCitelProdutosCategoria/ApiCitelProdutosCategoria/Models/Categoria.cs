﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiCitelProdutosCategoria.Models
{
    [Table("Categorias")]
    public class Categoria
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Título é obrigatório")]
        [StringLength(maximumLength:80, ErrorMessage = "O nome da Categoria deve ter no máximo 80 caractere.")]
        public string? Nome { get; set; }

        public DateTime DataCadastro { get; set; } = DateTime.Now;

    }
}
