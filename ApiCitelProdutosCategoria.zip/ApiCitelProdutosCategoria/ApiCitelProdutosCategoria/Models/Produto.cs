﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiCitelProdutosCategoria.Models
{
    [Table("Produto")]
    public class Produto
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="O campo Título é obrigatório")]
        [StringLength(maximumLength: 80, ErrorMessage = "O nome da Categoria deve ter no máximo 80 caractere.")]
        public string? Titulo { get; set; }

        [Required(ErrorMessage = "O campo Preço é de preenchimento obrigatório!")]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Preco { get; set; }

        [Required(ErrorMessage = "O campo Preço é de preenchimento obrigatório!")]
        public bool EmEstoque { get; set; }

        public int CategoriaId { get; set; }
    }
}
