﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ApiCitelProdutosCategoria.Migrations
{
    public partial class AjusteTamanhoColuna : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
