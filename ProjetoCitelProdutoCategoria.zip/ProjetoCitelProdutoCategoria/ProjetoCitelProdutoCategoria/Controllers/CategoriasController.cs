﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ProjetoCitelProdutoCategoria.Models;
using System.Text;

namespace ProjetoCitelProdutoCategoria.Controllers
{
    public class CategoriasController : Controller
    {
        //Variavel com o endereço de requisição a API
        private readonly string apiUrl = "https://localhost:7019/api/categorias";

        //Metodo index da View Categoria
        public async Task<IActionResult> Index()
        {
            List<Categoria> listaCategorias = new List<Categoria>();
            using (var httpContext = new HttpClient())
            {
                using (var response = await httpContext.GetAsync(apiUrl))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    listaCategorias = JsonConvert.DeserializeObject<List<Categoria>>(apiResponse);
                }
            }
            return View(listaCategorias);
        }

        //Metodo de consulta de todos os registros da entidade Categoria
        public ViewResult ConsultarCategorias() => View();

        //Metodo de consulta de registro da entidade Categoria por Id
        [HttpGet]
        public async Task<IActionResult> ConsultarCategorias(int id)
        {
            Categoria categoria = new Categoria();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    categoria = JsonConvert.DeserializeObject<Categoria>(apiResponse);
                }
            }
            return View(categoria);
        }

        //Metodo GET de inclusão de registro da entidade Categoria na API
        public ViewResult IncluirCategoria() => View();
        //Metodo POST de inclusão de registro da entidade Categoria na API
        [HttpPost]
        public async Task<IActionResult> IncluirCategoria(Categoria categoria)
        {
            Categoria categoriaRecebida= new Categoria();

            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(categoria),
                                                  Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync(apiUrl, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    categoriaRecebida = JsonConvert.DeserializeObject<Categoria>(apiResponse);
                }
            }
            return View(categoriaRecebida);
        }


        [HttpGet]
        public async Task<IActionResult> AtualizarCategoria(int id)
        {
            Categoria categoria = new Categoria();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    categoria = JsonConvert.DeserializeObject<Categoria>(apiResponse);
                }
            }
            return View(categoria);
        }
        [HttpPost]
        public async Task<IActionResult> AtualizarCategoria(Categoria categoria)
        {
            Categoria categoriaRecebida  = new Categoria();

            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(categoria.Id.ToString()), "Id");
                content.Add(new StringContent(categoria.DataCadastro.ToString()), "DataCadastro");
                content.Add(new StringContent(categoria.Nome), "Nome");

                using (var response = await httpClient.PutAsync(apiUrl + "/"+ categoria.Id, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Sucesso";
                    categoriaRecebida = JsonConvert.DeserializeObject<Categoria>(apiResponse);
                }
            }
            return View(categoriaRecebida);
        }


        public async Task<IActionResult> ExcluirCategoria(int id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }
            }
            ViewBag.DeleteCategoria = "Categoria ID " + id + " deletada";

            return View();
        }
    }
}


