﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using ProjetoCitelProdutoCategoria.Models;
using System.Text;

namespace ProjetoCitelProdutoCategoria.Controllers
{
    public class ProdutosController : Controller
    {
        //Variavel com o endereço de requisição a API
        private readonly string apiUrl = "https://localhost:7019/api/produtos";
        private readonly string apiUrlCategorias = "https://localhost:7019/api/categorias";

        public async Task<IActionResult> Index()
        {
            List<Produto> listaProdutos = new List<Produto>();
            List<Categoria> listaCategorias = new List<Categoria>();

            using (var httpContext = new HttpClient())
            {
                using (var response = await httpContext.GetAsync(apiUrl))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    listaProdutos = JsonConvert.DeserializeObject<List<Produto>>(apiResponse);
                }
            }

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrlCategorias))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    listaCategorias = JsonConvert.DeserializeObject<List<Categoria>>(apiResponse);
                }
            }

            ViewData["CategoriaId"] = new SelectList(listaCategorias, "Id", "Nome");

            return View(listaProdutos);
        }


        //Metodo de consulta de todos os registros da entidade Categoria
        public ViewResult ConsultarProdutos() => View();

        //Metodo de consulta de registro da entidade Categoria por Id
        [HttpGet]
        public async Task<IActionResult> ConsultarProdutos(int id)
        {
            Produto produto = new Produto();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    produto = JsonConvert.DeserializeObject<Produto>(apiResponse);
                }
            }
            return View(produto);
        }

        //Metodo GET de inclusão de registro da entidade Categoria na API
        public async Task<IActionResult> IncluirProduto()
        {
            List<Categoria> listaCategorias = new List<Categoria>();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrlCategorias))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    listaCategorias = JsonConvert.DeserializeObject<List<Categoria>>(apiResponse);
                }
            }

            ViewData["CategoriaId"] = new SelectList(listaCategorias, "Id", "Nome");

            return View();
        } 
        //Metodo POST de inclusão de registro da entidade Categoria na API
        [HttpPost]
        public async Task<IActionResult> IncluirProduto(Produto produto)
        {
            Produto produtoRecebido = new Produto();

            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(produto),
                                                  Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync(apiUrl, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    produtoRecebido = JsonConvert.DeserializeObject<Produto>(apiResponse);
                }
            }
            return View(produtoRecebido);
        }


        [HttpGet]
        public async Task<IActionResult> AtualizarProduto(int id)
        {
            Produto produto = new Produto();
            List<Categoria> categorias = new List<Categoria>();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    produto = JsonConvert.DeserializeObject<Produto>(apiResponse);
                }
            }

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(apiUrlCategorias ))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    categorias = JsonConvert.DeserializeObject<List<Categoria>>(apiResponse);
                }
            }

            ViewData["CategoriaId"] = new SelectList(categorias, "Id", "Nome", produto.CategoriaId);
            return View(produto);
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarProduto(Produto produto)
        {
            Produto produtoRecebido = new Produto();

            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(produto.Id.ToString()), "Id");
                content.Add(new StringContent(produto.Titulo), "Titulo");
                content.Add(new StringContent(produto.Preco.ToString()), "Preco");
                content.Add(new StringContent(produto.CategoriaId.ToString()), "CategoriaId");
                content.Add(new StringContent(produto.EmEstoque.ToString()), "Preco");

                using (var response = await httpClient.PutAsync(apiUrl + "/" + produto.Id, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Sucesso";
                    produtoRecebido = JsonConvert.DeserializeObject<Produto>(apiResponse);
                }
            }
            return View(produtoRecebido);
        }


        public async Task<IActionResult> ExcluirProduto(int id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync(apiUrl + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }
            }
            ViewBag.DeleteProduto = "Produto ID " + id + " deletado com sucesso";

            return View();
        }
    }
}
