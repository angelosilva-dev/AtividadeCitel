﻿using System.ComponentModel.DataAnnotations;

namespace ProjetoCitelProdutoCategoria.Models
{
    public class Categoria
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Título é obrigatório")]
        [StringLength(maximumLength: 80, ErrorMessage = "O nome da Categoria deve ter no máximo 80 caractere.")]
        [Display(Name ="Nome da Categoria")]
        public string Nome { get; set; }

        public DateTime DataCadastro { get; set; } = DateTime.Now;
    }
}
