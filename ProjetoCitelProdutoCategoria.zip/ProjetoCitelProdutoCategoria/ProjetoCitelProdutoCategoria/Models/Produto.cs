﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoCitelProdutoCategoria.Models
{
    public class Produto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Título é obrigatório")]
        [StringLength(maximumLength: 80, ErrorMessage = "O nome da Categoria deve ter no máximo 80 caractere.")]
        [Display(Name = "Nome do Produto")]
        public string? Titulo { get; set; }

        [Required(ErrorMessage = "O campo Preço é de preenchimento obrigatório!")]
        [Column(TypeName = "decimal(10,2)")]
        [Display(Name ="Preço do Produto")]
        public decimal Preco { get; set; }

        [Required(ErrorMessage = "O campo Preço é de preenchimento obrigatório!")]
        [Display(Name = "Produto em Estoque?")]
        public bool EmEstoque { get; set; }

        public int CategoriaId { get; set; }

        public virtual Categoria? Categorias { get; set; }
    }
}
